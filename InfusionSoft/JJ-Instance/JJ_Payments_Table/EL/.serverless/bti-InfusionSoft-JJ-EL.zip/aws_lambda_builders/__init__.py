"""
AWS Lambda Builder Library
"""
__version__ = "1.6.0"
RPC_PROTOCOL_VERSION = "0.3"
